# Nourish — Standardized Clinical Charting

A learning module for documenting the four steps of the Nutrition Care Process in a structured clinical note.

## Included

- Responsive provider charting interface with progress navigation across Assessment, Nutrition Diagnosis, Intervention, and Monitoring & Evaluation.
- Assessment domains, PES statement builder, intervention strategy choices, and monitoring indicator choices.
- JSON Schema 2020-12 artifact at `src/data/encpt-chart-schema.json` with example terminology lists.
- Live clinical summary, browser-local draft persistence, copy-to-clipboard, print, and structured JSON download.
- Required-field indicators and sample notes; this is a front-end learning artifact and does not send patient data to a server.

## Run locally

```sh
npm install
npm run dev
```

## Validate

```sh
npm run lint
npm run build
```

## Terminology and privacy notice

The example labels are illustrative only and are not a complete or authoritative eNCPT terminology list. Verify terminology and definitions against the current licensed eNCPT release and local organizational standards before clinical use. This application is not a production EHR, is not validated for clinical care, and stores draft data in the current browser's local storage. Do not enter real patient-identifying information into this demo.
