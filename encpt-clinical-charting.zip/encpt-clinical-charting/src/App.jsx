import { useEffect, useMemo, useState } from 'react'
import chartSchema from './data/encpt-chart-schema.json'
import './App.css'

const steps = [
  { id: 'assessment', number: '01', title: 'Assessment', subtitle: 'Collect & evaluate data', icon: '◉' },
  { id: 'diagnosis', number: '02', title: 'Nutrition diagnosis', subtitle: 'Write a PES statement', icon: '⌕' },
  { id: 'intervention', number: '03', title: 'Intervention', subtitle: 'Plan nutrition care', icon: '↗' },
  { id: 'monitoringEvaluation', number: '04', title: 'Monitor & evaluate', subtitle: 'Measure outcomes', icon: '⌁' },
]

const today = new Date().toISOString().slice(0, 10)
const initialNote = {
  patient: { name: '', recordNumber: '', dateOfBirth: '', encounterDate: today, referralReason: '' },
  assessment: {
    foodNutritionRelatedHistory: '', anthropometricMeasurements: '',
    biochemicalMedicalTestsProcedures: '', nutritionFocusedPhysicalFindings: '', clientHistory: '',
  },
  diagnosis: { problem: '', etiology: '', signsSymptoms: '' },
  intervention: { strategy: '', details: '', goalsExpectedOutcomes: '', coordinationOfCare: '' },
  monitoringEvaluation: { indicator: '', targetOutcome: '', followUpPlan: '' },
}

function loadDraft() {
  try {
    const saved = localStorage.getItem('encpt-charting-draft')
    return saved ? { ...initialNote, ...JSON.parse(saved) } : initialNote
  } catch {
    return initialNote
  }
}

function App() {
  const [note, setNote] = useState(loadDraft)
  const [activeStep, setActiveStep] = useState('assessment')
  const [toast, setToast] = useState('')

  useEffect(() => {
    localStorage.setItem('encpt-charting-draft', JSON.stringify(note))
  }, [note])

  const pesStatement = useMemo(() => {
    const { problem, etiology, signsSymptoms } = note.diagnosis
    return problem && etiology && signsSymptoms
      ? `${problem} related to ${etiology} as evidenced by ${signsSymptoms}.`
      : 'Complete the three PES components to generate a diagnosis statement.'
  }, [note.diagnosis])

  const completedSteps = steps.filter(({ id }) => {
    if (id === 'assessment') return Object.values(note.assessment).some(Boolean)
    if (id === 'diagnosis') return Boolean(note.diagnosis.problem && note.diagnosis.etiology && note.diagnosis.signsSymptoms)
    if (id === 'intervention') return Boolean(note.intervention.strategy && note.intervention.details)
    return Boolean(note.monitoringEvaluation.indicator && note.monitoringEvaluation.followUpPlan)
  }).length

  function update(section, field, value) {
    setNote((current) => ({ ...current, [section]: { ...current[section], [field]: value } }))
  }

  function notify(message) {
    setToast(message)
    window.setTimeout(() => setToast(''), 2600)
  }

  function buildExport() {
    return {
      schemaVersion: '1.0.0',
      terminologyNotice: 'Educational example. Confirm terminology against the current licensed eNCPT release before clinical use.',
      patient: note.patient,
      assessment: Object.fromEntries(Object.entries(note.assessment).map(([key, finding]) => [key, { finding }])),
      diagnosis: { ...note.diagnosis, pesStatement },
      intervention: note.intervention,
      monitoringEvaluation: note.monitoringEvaluation,
      generatedAt: new Date().toISOString(),
    }
  }

  function downloadNote() {
    const blob = new Blob([JSON.stringify(buildExport(), null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'nutrition-care-note.json'
    link.click()
    URL.revokeObjectURL(url)
    notify('Standardized note exported as JSON')
  }

  async function copyNote() {
    const text = `${note.patient.name || 'Patient'} · ${note.patient.encounterDate}\n\nAssessment\n${Object.values(note.assessment).filter(Boolean).join('\n') || 'Not documented'}\n\nPES statement\n${pesStatement}\n\nIntervention\n${note.intervention.strategy || 'Not selected'}: ${note.intervention.details || 'Not documented'}\n\nMonitoring & evaluation\n${note.monitoringEvaluation.indicator || 'Not selected'}: ${note.monitoringEvaluation.followUpPlan || 'Not documented'}`
    try {
      await navigator.clipboard.writeText(text)
      notify('Clinical note copied to clipboard')
    } catch {
      notify('Clipboard access is unavailable in this browser')
    }
  }

  function renderField(label, section, field, options = {}) {
    const value = note[section][field] || ''
    const common = {
      id: `${section}-${field}`,
      value,
      onChange: (event) => update(section, field, event.target.value),
      placeholder: options.placeholder || 'Enter details…',
      required: options.required,
    }
    return (
      <label className={`field ${options.wide ? 'field-wide' : ''}`} htmlFor={common.id} key={field}>
        <span>{label}{options.required && <b className="required"> *</b>}</span>
        {options.options ? (
          <select {...common}>
            <option value="">Select a standardized term</option>
            {options.options.map((option) => <option value={option.value || option} key={option.value || option}>{option.label || option}</option>)}
          </select>
        ) : options.multiline ? (
          <textarea {...common} rows={options.rows || 3} />
        ) : (
          <input {...common} type={options.type || 'text'} />
        )}
        {options.hint && <small>{options.hint}</small>}
      </label>
    )
  }

  function renderStep() {
    if (activeStep === 'assessment') return (
      <>
        <div className="section-heading"><div><span className="eyebrow">STEP 01 · NUTRITION ASSESSMENT</span><h2>Start with the story</h2><p>Capture relevant, measurable data across the assessment domains.</p></div><span className="section-icon">◉</span></div>
        <div className="form-grid patient-grid">
          {renderField('Patient name', 'patient', 'name', { required: true, placeholder: 'e.g. Jordan Lee' })}
          {renderField('Medical record number', 'patient', 'recordNumber', { placeholder: 'Optional' })}
          {renderField('Date of birth', 'patient', 'dateOfBirth', { type: 'date' })}
          {renderField('Encounter date', 'patient', 'encounterDate', { type: 'date', required: true })}
          {renderField('Reason for referral', 'patient', 'referralReason', { wide: true, placeholder: 'Reason for nutrition consultation' })}
        </div>
        <div className="divider-label"><span>ASSESSMENT DOMAINS</span><i /></div>
        <div className="form-grid">
          {renderField('Food / nutrition-related history', 'assessment', 'foodNutritionRelatedHistory', { multiline: true, placeholder: 'Dietary intake, supplement use, food access, preferences…', hint: 'Include source and timeframe when available.' })}
          {renderField('Anthropometric measurements', 'assessment', 'anthropometricMeasurements', { multiline: true, placeholder: 'Height, weight, BMI, weight history…' })}
          {renderField('Biochemical data, tests & procedures', 'assessment', 'biochemicalMedicalTestsProcedures', { multiline: true, placeholder: 'Relevant labs, medical tests, procedures…' })}
          {renderField('Nutrition-focused physical findings', 'assessment', 'nutritionFocusedPhysicalFindings', { multiline: true, placeholder: 'Nutrition-related physical signs, appetite, function…' })}
          {renderField('Client history', 'assessment', 'clientHistory', { multiline: true, wide: true, placeholder: 'Medical / social history and context relevant to nutrition care…' })}
        </div>
      </>
    )

    if (activeStep === 'diagnosis') return (
      <>
        <div className="section-heading"><div><span className="eyebrow">STEP 02 · NUTRITION DIAGNOSIS</span><h2>Connect the evidence</h2><p>Build a nutrition diagnosis using the PES (Problem, Etiology, Signs/Symptoms) format.</p></div><span className="section-icon">⌕</span></div>
        <div className="form-grid diagnosis-grid">
          {renderField('Problem (P)', 'diagnosis', 'problem', { options: chartSchema.terminology.diagnosisExamples, required: true, hint: 'Choose the most relevant standardized diagnosis label.' })}
          {renderField('Etiology (E)', 'diagnosis', 'etiology', { multiline: true, required: true, placeholder: 'Related to… (the root cause you can address)' })}
          {renderField('Signs & symptoms (S)', 'diagnosis', 'signsSymptoms', { multiline: true, wide: true, required: true, placeholder: 'As evidenced by… (specific, relevant assessment findings)' })}
        </div>
        <div className="pes-preview"><div className="preview-top"><span className="eyebrow">GENERATED PES STATEMENT</span><span className="live-tag"><i /> LIVE PREVIEW</span></div><p>{pesStatement}</p><div className="pes-key"><span><b>P</b> Problem</span><span><b>E</b> Etiology</span><span><b>S</b> Signs & symptoms</span></div></div>
        <div className="notice"><span>ⓘ</span><p>Use the current eNCPT terminology set used by your organization. The examples in this learning module are illustrative, not an official code list.</p></div>
      </>
    )

    if (activeStep === 'intervention') return (
      <>
        <div className="section-heading"><div><span className="eyebrow">STEP 03 · NUTRITION INTERVENTION</span><h2>Make the plan actionable</h2><p>Document the strategy, specific action, and expected outcome.</p></div><span className="section-icon">↗</span></div>
        <div className="form-grid">
          {renderField('Intervention strategy', 'intervention', 'strategy', { options: chartSchema.terminology.interventionStrategies, required: true })}
          {renderField('Expected outcome / goal', 'intervention', 'goalsExpectedOutcomes', { placeholder: 'A measurable, person-centered outcome' })}
          {renderField('Intervention details', 'intervention', 'details', { multiline: true, wide: true, required: true, placeholder: 'What will be done, by whom, how often, and with what resources?' })}
          {renderField('Coordination of nutrition care', 'intervention', 'coordinationOfCare', { multiline: true, wide: true, placeholder: 'Referrals, team communication, or handoff plan…' })}
        </div>
        <div className="notice"><span>✦</span><p>Keep the plan individualized and document shared decisions, readiness, and barriers when relevant.</p></div>
      </>
    )

    return (
      <>
        <div className="section-heading"><div><span className="eyebrow">STEP 04 · MONITORING & EVALUATION</span><h2>Close the feedback loop</h2><p>Choose indicators that show whether the intervention is working.</p></div><span className="section-icon">⌁</span></div>
        <div className="form-grid">
          {renderField('Monitoring indicator', 'monitoringEvaluation', 'indicator', { options: chartSchema.terminology.monitoringIndicators, required: true })}
          {renderField('Target / expected outcome', 'monitoringEvaluation', 'targetOutcome', { placeholder: 'Define a meaningful target, if appropriate' })}
          {renderField('Follow-up plan', 'monitoringEvaluation', 'followUpPlan', { multiline: true, wide: true, required: true, placeholder: 'When will this be reviewed? Who will follow up, and how?' })}
        </div>
        <div className="outcome-card"><span className="outcome-icon">↻</span><div><strong>Evaluate against the assessment</strong><p>Compare follow-up findings with the baseline and revise the nutrition care plan as needed.</p></div></div>
      </>
    )
  }

  const activeIndex = steps.findIndex((step) => step.id === activeStep)
  const activeStepMeta = steps[activeIndex]

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="#top"><span className="brand-mark">n<span>+</span></span><span className="brand-copy">nourish<span>clinical workspace</span></span></a>
        <div className="workspace-label">WORKSPACE</div>
        <button className="workspace-switch"><span className="workspace-avatar">NC</span><span>Nutrition care<span>Outpatient clinic</span></span><b>⌄</b></button>
        <div className="side-label">CHARTING</div>
        <button className="side-link"><span>▦</span>Patient overview</button>
        <button className="side-link active"><span>✎</span>Nutrition note</button>
        <button className="side-link"><span>◷</span>Encounter history</button>
        <div className="side-label step-label">NOTE PROGRESS <span>{completedSteps}/4</span></div>
        <nav className="step-nav" aria-label="Nutrition care process steps">
          {steps.map((step, index) => <button key={step.id} className={`step-nav-item ${activeStep === step.id ? 'selected' : ''} ${completedSteps > index ? 'done' : ''}`} onClick={() => setActiveStep(step.id)}><span className="step-dot">{completedSteps > index ? '✓' : step.number}</span><span className="step-nav-text">{step.title}<small>{step.subtitle}</small></span></button>)}
        </nav>
        <div className="sidebar-bottom"><div className="secure-note"><span>▣</span><p><strong>Privacy first</strong><br />Draft stays in this browser.</p></div><button className="profile"><span className="profile-avatar">AM</span><span>Alex Morgan<small>Registered dietitian</small></span><b>···</b></button></div>
      </aside>

      <main className="main-area" id="top">
        <header className="topbar"><div className="breadcrumbs">Patients <span>/</span> New encounter <span>/</span> <strong>Nutrition note</strong></div><div className="top-actions"><span className="save-state"><i /> Draft saved</span><button className="icon-button" aria-label="Help">?</button><button className="top-avatar" aria-label="Profile">AM</button></div></header>
        <div className="page-content">
          <div className="page-title-row"><div><div className="eyebrow page-eyebrow">CLINICAL DOCUMENTATION <span>·</span> NUTRITION CARE PROCESS</div><h1>Nutrition care note</h1><p className="page-subtitle">A structured note, guided by standardized terminology.</p></div><button className="outline-button" onClick={() => window.print()}><span>⎙</span> Print note</button></div>
          <div className="patient-strip"><div className="patient-avatar">{note.patient.name ? note.patient.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase() : '＋'}</div><div className="patient-summary"><strong>{note.patient.name || 'New patient'}</strong><span>{note.patient.recordNumber ? `MRN ${note.patient.recordNumber}` : 'Patient details not entered'} <i /> {note.patient.dateOfBirth ? `DOB ${note.patient.dateOfBirth}` : 'No DOB'}</span></div><div className="strip-divider" /><div className="encounter-summary"><span>ENCOUNTER DATE</span><strong>{note.patient.encounterDate || 'Not set'}</strong></div><span className="draft-pill"><i /> IN PROGRESS</span></div>

          <div className="process-progress"><div className="progress-copy"><strong>Nutrition Care Process</strong><span>{completedSteps} of 4 steps started</span></div><div className="progress-track">{steps.map((step, index) => <button key={step.id} aria-label={`Go to ${step.title}`} className={completedSteps > index ? 'filled' : ''} onClick={() => setActiveStep(step.id)} />)}</div><div className="progress-steps">{steps.map((step) => <button key={step.id} className={activeStep === step.id ? 'current' : ''} onClick={() => setActiveStep(step.id)}>{step.title}</button>)}</div></div>

          <div className="workspace-grid"><section className="form-card"><div className="form-card-content">{renderStep()}</div><div className="form-footer"><span><span className="required">*</span> Required for this step</span><div><button className="text-button" onClick={() => { setNote(initialNote); localStorage.removeItem('encpt-charting-draft'); notify('Draft cleared') }}>Clear draft</button>{activeIndex > 0 && <button className="secondary-button" onClick={() => setActiveStep(steps[activeIndex - 1].id)}>← Previous</button>}{activeIndex < steps.length - 1 ? <button className="primary-button" onClick={() => setActiveStep(steps[activeIndex + 1].id)}>Continue <span>→</span></button> : <button className="primary-button" onClick={downloadNote}>Generate note <span>↗</span></button>}</div></div></section>

            <aside className="summary-column"><section className="summary-card"><div className="summary-header"><div><span className="eyebrow">NOTE PREVIEW</span><h3>Clinical summary</h3></div><button className="more-button" aria-label="More options">···</button></div><div className="summary-meta"><span className="summary-type">NUTRITION ASSESSMENT</span><span>{note.patient.encounterDate || today}</span></div><div className="summary-section"><div className="summary-section-title"><span className="mini-icon">◉</span><strong>Assessment</strong><span className="summary-status">{Object.values(note.assessment).filter(Boolean).length ? 'IN PROGRESS' : 'PENDING'}</span></div><p>{note.assessment.foodNutritionRelatedHistory || note.assessment.anthropometricMeasurements || 'Assessment findings will appear here as you document.'}</p>{Object.values(note.assessment).filter(Boolean).length > 1 && <small>+ {Object.values(note.assessment).filter(Boolean).length - 1} more documented finding(s)</small>}</div><div className="summary-section"><div className="summary-section-title"><span className="mini-icon purple">⌕</span><strong>Nutrition diagnosis</strong><span className="summary-status">{note.diagnosis.problem ? 'IN PROGRESS' : 'PENDING'}</span></div><p className="pes-summary">{note.diagnosis.problem ? pesStatement : 'PES statement will be generated here.'}</p></div><div className="summary-section"><div className="summary-section-title"><span className="mini-icon orange">↗</span><strong>Intervention</strong><span className="summary-status">{note.intervention.strategy ? 'IN PROGRESS' : 'PENDING'}</span></div><p>{note.intervention.details || 'Intervention plan will appear here.'}</p></div><div className="summary-section last"><div className="summary-section-title"><span className="mini-icon blue">⌁</span><strong>Monitoring & evaluation</strong><span className="summary-status">{note.monitoringEvaluation.indicator ? 'IN PROGRESS' : 'PENDING'}</span></div><p>{note.monitoringEvaluation.followUpPlan || 'Follow-up plan will appear here.'}</p></div><button className="copy-button" onClick={copyNote}><span>▣</span> Copy note text</button></section><div className="standards-note"><span>✧</span><p><strong>Aligned with the Nutrition Care Process</strong><br />Standardized terminology helps make care consistent, clear, and measurable.</p></div><button className="export-button" onClick={downloadNote}><span>↓</span> Export structured JSON</button></aside></div>
          <footer className="page-footer"><span>eNCPT terminology examples are for learning purposes. Verify terms against your licensed, current edition.</span><a href="#top" onClick={() => setActiveStep('assessment')}>Back to top ↑</a></footer>
        </div>
      </main>
      {toast && <div className="toast" role="status">✓ &nbsp;{toast}</div>}
      <span className="sr-only">Current section: {activeStepMeta.title}</span>
    </div>
  )
}

export default App
